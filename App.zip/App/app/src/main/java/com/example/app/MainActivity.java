package com.example.app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import android.os.Bundle;

import java.util.Arrays;
import java.util.LinkedList;

public class MainActivity extends AppCompatActivity {
//add 100 words to the list
    LinkedList<String> mWordList = new LinkedList<>(Arrays.asList( "World", "This", "Is", "Android", "Development", "With", "Java","World", "This", "Is", "Android", "Development", "With", "Java","World", "This", "Is", "Android", "Development", "With", "Java","World", "This", "Is", "Android", "Development", "With", "Java","World", "This", "Is", "Android", "Development", "With", "Java","World", "This", "Is", "Android", "Development", "With", "Java","World", "This", "Is", "Android", "Development", "With", "Java","World", "This", "Is", "Android", "Development", "With", "Java"));
    RecyclerView mRecyclerView;
    WordListAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mRecyclerView = findViewById(R.id.recyclerview);

        mAdapter = new WordListAdapter(this, mWordList);

        mRecyclerView.setAdapter(mAdapter);

        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));


    }
}